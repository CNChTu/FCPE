import sys
sys.path.append('../')

import argparse
import torch
from torch.optim import lr_scheduler
from saver import utils
from data_loaders_wav_multi import get_data_loader, get_data_set
from model_with_bce import TransformerF0BCE
import torch.multiprocessing as mp

import numpy as np
import torch
import time
from saver.saver import Saver
from saver import utils
from torch import autocast
from torch.cuda.amp import GradScaler

from mir_eval.melody import raw_pitch_accuracy, to_cent_voicing, raw_chroma_accuracy, overall_accuracy
from mir_eval.melody import voicing_recall, voicing_false_alarm
import gc
import torch.distributed as dist  # noqa: E402
from torch.nn.parallel import DistributedDataParallel as DDP
import os

USE_MIR = True

def parse_args(args=None, namespace=None):
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-c",
        "--config",
        type=str,
        required=True,
        help="path to the config file")
    return parser.parse_args(args=args, namespace=namespace)


@torch.no_grad()
def test(args, model, loader_test, saver, rank):
    print(' [*] testing...')
    model.eval()

    # losses
    _rpa = _rca = _oa = _vfa = _vr = test_loss = 0.
    _num_a = 0

    # intialization
    num_batches = len(loader_test)
    rtf_all = []

    # run
    with torch.no_grad():
        for bidx, data in enumerate(loader_test):
            fn = data[2][0]
            print('--------')
            print('{}/{} - {}'.format(bidx, num_batches, fn))

            # unpack data
            #for k in data.keys():
            #    if not k.startswith('name'):
            #        data[k] = data[k].to(args.device)
            for k in range(len(data)):
                if k < 2:
                    data[k] = data[k].to(args.device+":0")
            #print('>>', data[2][0])

            # forward
            st_time = time.time()
            f0 = model(mel=data[0], infer=True)
            ed_time = time.time()

            if USE_MIR and rank == 0:
                _f0 = ((f0.exp() - 1) * 700).squeeze().cpu().numpy()
                _df0 = data[1].squeeze().cpu().numpy()

                time_slice = np.array([i * args.mel.hop_size * 1000 / args.mel.sampling_rate for i in range(len(_df0))])
                ref_v, ref_c, est_v, est_c = to_cent_voicing(time_slice, _df0, time_slice, _f0)

                rpa = raw_pitch_accuracy(ref_v, ref_c, est_v, est_c)
                rca = raw_chroma_accuracy(ref_v, ref_c, est_v, est_c)
                oa = overall_accuracy(ref_v, ref_c, est_v, est_c)
                vfa = voicing_false_alarm(ref_v, est_v)
                vr = voicing_recall(ref_v, est_v)

            if rank == 0:
                # RTF
                run_time = ed_time - st_time
                song_time = f0.shape[1] * args.mel.hop_size / args.mel.sampling_rate
                rtf = run_time / song_time
                print('RTF: {}  | {} / {}'.format(rtf, run_time, song_time))
                if USE_MIR and rank == 0:
                    print('RPA: {}  | RCA: {} | OA: {} | VFA: {} | VR: {} |'.format(rpa, rca, oa, vfa, vr))
                rtf_all.append(rtf)

            # loss
            for i in range(args.train.batch_size):
                loss = model(mel=data[0], infer=False, gt_f0=data[1])
                test_loss += loss.item()

            if USE_MIR and rank == 0:
                _rpa = _rpa + rpa
                _rca = _rca + rca
                _oa = _oa + oa
                _vfa = _vfa + vfa
                _vr = _vr + vr
                _num_a = _num_a + 1
            
            if rank == 0:
                # log mel
                saver.log_spec(data[3][0], data[0], data[0])

                saver.log_f0(data[3][0], f0, data[1])
                saver.log_f0(data[3][0], f0, data[1], inuv=True)
    
    if rank == 0:
    # report
        test_loss /= args.train.batch_size
        test_loss /= num_batches

    if USE_MIR and rank == 0:
        _rpa /= _num_a

        _rca /= _num_a

        _oa /= _num_a

        _vfa /= _num_a

        _vr /= _num_a

    if rank == 0:
        # check
        print(' [test_loss] test_loss:', test_loss)
        print(' Real Time Factor', np.mean(rtf_all))
    return test_loss, _rpa, _rca, _oa, _vfa, _vr



def train(rank, config_path, data_train, data_valid):
    args = utils.load_config(config_path)
    dist.init_process_group(backend= 'gloo' if os.name == 'nt' else 'nccl', init_method='env://', world_size=args.train.n_gpus , rank=rank)
    torch.cuda.set_device(rank)
    if args.model.type == 'TransformerF0BCE':
        model = TransformerF0BCE(
            input_channel=args.model.input_channel,
            out_dims=args.model.out_dims,
            n_layers=args.model.n_layers,
            n_chans=args.model.n_chans,
            use_siren=args.model.use_siren,
            use_full=args.model.use_full,
            loss_mse_scale=args.loss.loss_mse_scale,
            loss_l2_regularization=args.loss.loss_l2_regularization,
            loss_l2_regularization_scale=args.loss.loss_l2_regularization_scale,
            loss_grad1_mse=args.loss.loss_grad1_mse,
            loss_grad1_mse_scale=args.loss.loss_grad1_mse_scale,
            f0_max=args.model.f0_max,
            f0_min=args.model.f0_min,
            confidence=args.model.confidence,
            threshold=args.model.threshold,
            use_input_conv=args.model.use_input_conv,
            residual_dropout=args.model.residual_dropout,
            attention_dropout=args.model.attention_dropout
        ).cuda()
    else:
        raise ValueError(f" [x] Unknown Model: {args.model.type}")
    optimizer = torch.optim.AdamW(model.parameters())
    initial_global_step, model, optimizer = utils.load_model(args.env.expdir, model, optimizer, device=args.device)
    # saver
    saver = Saver(args, initial_global_step = initial_global_step, rank = rank)
    if rank == 0:
        print(' > config:', config_path)
        print(' >    exp:', args.env.expdir)

        # model size
        params_count = utils.get_network_paras_amount({'model': model})
        saver.log_info('--- model size ---')
        saver.log_info(params_count)
   
    for param_group in optimizer.param_groups:
        param_group['initial_lr'] = args.train.lr
        param_group['lr'] = args.train.lr * args.train.gamma ** max((initial_global_step - 2) // args.train.decay_step,
                                                                    0)
        param_group['weight_decay'] = args.train.weight_decay

    for state in optimizer.state.values():
        for k, v in state.items():
            if torch.is_tensor(v):
                state[k] = v.to(args.device)
    
    scheduler = lr_scheduler.StepLR(optimizer, step_size=args.train.decay_step, gamma=args.train.gamma,
                                    last_epoch=initial_global_step - 2)
    model = DDP(model, device_ids=[rank])
    
    loader_train, loader_test = get_data_loader(args, data_train, data_valid, rank)
    # run   
    num_batches = len(loader_train)
    model.train()
    if rank == 0:
        saver.log_info('======= start training =======')
    scaler = GradScaler()
    if args.train.amp_dtype == 'fp32':
        dtype = torch.float32
    elif args.train.amp_dtype == 'fp16':
        dtype = torch.float16
    elif args.train.amp_dtype == 'bf16':
        dtype = torch.bfloat16
    else:
        raise ValueError(' [x] Unknown amp_dtype: ' + args.train.amp_dtype)
    for epoch in range(args.train.epochs):
        train_one_epoch(loader_train,saver,optimizer,model,dtype,scaler,epoch,args,scheduler,num_batches,loader_test,rank)
        # 手动gc,防止内存泄漏
        gc.collect()

def train_one_epoch(loader_train,saver,optimizer,model,dtype,scaler,epoch,args,scheduler,num_batches,loader_test,rank):
    for batch_idx, data in enumerate(loader_train):
        train_one_step(batch_idx, data, saver,optimizer,model,dtype,scaler,epoch,args,scheduler,num_batches,loader_test,rank)


def train_one_step(batch_idx, data, saver,optimizer,model,dtype,scaler,epoch,args,scheduler,num_batches,loader_test,rank):
    saver.global_step_increment()
    optimizer.zero_grad()

    # unpack data
    for k in range(len(data)):
        if k < 2:
            data[k] = data[k].cuda()
    #print('>>', data[2][0])

    # forward
    if dtype == torch.float32:
        loss = model(mel=data[0], infer=False, gt_f0=data[1])
    else:
        with autocast(device_type=args.device+f":{rank}", dtype=dtype):
            loss = model(mel=data[0], infer=False, gt_f0=data[1])

    # handle nan loss
    if torch.isnan(loss):
        # raise ValueError(' [x] nan loss ')
        if rank == 0: print(' [x] nan loss ')
        loss = None
        return
    else:
        # backpropagate
        if dtype == torch.float32:
            loss.backward()
            optimizer.step()
        else:
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        scheduler.step()

    # log loss
    if rank == 0 and saver.global_step % args.train.interval_log == 0:
        current_lr = optimizer.param_groups[0]['lr']
        saver.log_info(
            'epoch: {} | {:3d}/{:3d} | {} | batch/s: {:.2f} | lr: {:.6} | loss: {:.3f} | time: {} | step: {}'.format(
                epoch,
                batch_idx,
                num_batches,
                args.env.expdir,
                args.train.interval_log / saver.get_interval_time(),
                current_lr,
                loss.item(),
                saver.get_total_time(),
                saver.global_step
            )
        )
        saver.log_value({
            'train/loss': loss.item()
        })
        saver.log_value({
            'train/lr': current_lr
        })

    # validation
    if rank == 0 and saver.global_step % args.train.interval_val == 0 :
        optimizer_save = optimizer if args.train.save_opt else None

        # save latest
        saver.save_model(model.module, optimizer_save, postfix=f'{saver.global_step}')
        last_val_step = saver.global_step - args.train.interval_val
        if last_val_step % args.train.interval_force_save != 0:
            saver.delete_model(postfix=f'{last_val_step}')

        # run testing set
        test_loss, rpa, rca, oa, vfa, vr = test(args, model, loader_test, saver, rank)

        # log loss
        saver.log_info(
            ' --- <validation> --- \nloss: {:.3f}. '.format(
                test_loss,
            )
        )

        saver.log_value({
            'validation/loss': test_loss
        })
        if USE_MIR:
            saver.log_value({
                'validation/rpa': rpa
            })
            saver.log_value({
                'validation/rca': rca
            })
            saver.log_value({
                'validation/oa': oa
            })
            saver.log_value({
                'validation/vfa': vfa
            })
            saver.log_value({
                'validation/vr': vr
            })

        model.train()

def main():
    cmd = parse_args()
    
    args = utils.load_config(cmd.config)
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '8001'
    # run
    data_train, data_valid = get_data_set(args)
    mp.spawn(train, nprocs=args.train.n_gpus, args=(cmd.config, data_train, data_valid))

if __name__ == '__main__':
    main()
    